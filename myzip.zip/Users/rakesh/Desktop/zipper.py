import zipfile36 as zipfile

with zipfile('spam.zip', 'w') as myzip:
    myzip.write('eggs.txt')
